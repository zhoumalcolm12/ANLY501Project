"clustering.py": python document for 501 project clustering part: read in data and process ward,k-means,dbscan clustering analysis and PCA plot graphs.
"cleandata.csv": input data for clustering analysis
“clustering_insights.py”: python code for clustering insights, using flight altitude, flight speed and departure delay attributes
“df_ml_wo_weather”: input file of clustering_insights.py




