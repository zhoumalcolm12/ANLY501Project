"cleandata.csv": input file of hypothesis_testing.py
"hypothesis_testing.py": python code for hypothesis tesiting